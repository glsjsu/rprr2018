clear
close all
clc

fprintf('Scalable spectral clustering with cosine similarity,\nG. Chen, ICPR 2018, Beijing, China\n')

%% process data
% This script generates the processed 20news data under the Data/
% subdirectory (which has already been provided). 
% It requires the following 5 files 
% train.data, test.data, train.label, test.label, and vocabulary.txt 
% from the Matlab bydate version of the 20newsgroup data set
% at http://qwone.com/~jason/20Newsgroups/; 
% they should also be stored the Data subdirectory.

%script_20news_processing

%% Table I of the paper
script_20news_results

%% Fig. 2 of the paper
script_20news_insights

%% Fig. 3 of the paper
script_20news_alpha

%% Fig. 4 of the paper
script_tdt2_top30_results

%% Table II of the paper
script_digits_results

