clear

load Data\20news
k = 20;
n = numel(y);

alphas = 0:0.005:0.05; % percentage of outliers to be removed
n_alphas = length(alphas);

accuracy = zeros(4,n_alphas);

%% 
fprintf('\n***Sensitivity study of parameter alpha (Fig. 3)***\n')

for i = 1:n_alphas
    
    fprintf('...alpha=%1.3f...\n', alphas(i))
    
    % scalable NJW on 100d projection
    inds_sc = ssc_cosine(A_tfidf_svd100, k, struct('t', -1,'alpha', alphas(i)));
    inds_sc = bestMap(y,inds_sc);
    accuracy(1,i) = sum(y == inds_sc)/n;

    % plain NJW on 100d projection
    inds_sc = specluster(A_tfidf_svd100, k, struct('t', -1, 'affinity', 'cosine', 'alpha', alphas(i)));
    inds_sc = bestMap(y,inds_sc);
    accuracy(2,i) = sum(y == inds_sc)/n;
    
    % scalable NJW on data of no projection
    inds_sc = ssc_cosine(A_tfidf, k, struct('t', -1,'alpha', alphas(i)));
    inds_sc = bestMap(y,inds_sc);
    accuracy(3,i) = sum(y == inds_sc)/n;
    
    % plain NJW on data of no projection
    inds_sc = specluster(A_tfidf, k, struct('t', -1, 'affinity', 'cosine', 'alpha', alphas(i)));
    inds_sc = bestMap(y,inds_sc);
    accuracy(4,i) = sum(y == inds_sc)/n;
    
end

%%
figure; 
hold on
plot(alphas, accuracy(1,:), '--rs', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(2,:), '--bs', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(3,:), '--r*', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(4,:), '--b*', 'markersize',14, 'linewidth',2)
xlabel('alpha (fraction of outliers)','fontsize',14)
ylabel('clustering accuracy','fontsize',14)
grid on
legend({'sNJW (SVD 100)', 'NJW (SVD 100)', 'sNJW (no projection)', 'NJW (no projection)'}, 'fontsize', 14)
set(gca, 'fontsize',14)

