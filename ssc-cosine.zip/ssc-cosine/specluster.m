function [labels, outliers] = specluster(X, k, opts)

% Spectral clustering
%
% Input
%   X: n by d data matrix
%   k: number of clusters
%   opts: a structure array with the following fields
%     .t: a variable indicating the clustering method to be used:
%         t=-1 NJW  
%         t=0: NCut (default) 
%         t>=1: DM with t time steps
%     .affinity: 'Gaussian'  or 'cosine'(default) 
%     .sigmaValue: radius or # nearest neighbors (default=7), or power (default=1) depending on sigmaMethod used below
%     .sigmaMethod: a string, one of the following
%         'direct': in this case sigmaValue refers to the sigma in the gaussian kernel
%         'meanDist'(default): mean distance of points to their sigmaValue nearest neighbors
%         'medianDist': median distance of points to their sigmaValue nearest neighbors
%         'selfTuning': sigmaValue = # nearest neighbors
%     .normalizeL: whether or not to normalize the graph Laplacian. Default = true
%     .alpha: a number between 0 (default) and 1 representing the
%         fraction of outliers to be removed
%     .classify_outliers: logical variable indicating whether to 
%         classify outliers back to the data. Default = false.
% Ouput
%   labels: group labels {1,...,k) or {0,1,...,k} found by algorithm: 
%           (1) when opts.classify_outliers = true, outliers will be 
%               classified into the clusters and thus receive positive labels;
%           (2) when opts.classify_outliers = false, no classification
%               will be done and outliers have zero labels 
%   outliers: logical variable indicating whether each point is an outlier.
%
% @Guangliang Chen (2018)

%% set parameters

if nargin<3
    opts = struct();
end

if ~isfield(opts,'isRowNormalized')
    opts.isRowNormalized = false;
end

if ~isfield(opts, 't')
    opts.t = 0; % default = NCut
end

if ~isfield(opts, 'alpha')
    opts.alpha = 0.01; % default = 1% outliers removed
end

if ~isfield(opts, 'affinity')
    opts.affinity = 'cosine';
end

switch(opts.affinity)
    
     case 'cosine'
        
         if ~isfield(opts, 'sigmaMethod')
            opts.sigmaMethod = 'power';
         end
        
        if ~isfield(opts, 'sigmaValue')
            opts.sigmaValue = 1;
        end
        
    case 'Gaussian'

        if ~isfield(opts, 'sigmaMethod')
            opts.sigmaMethod = 'meanDist';
        end
        
        if ~isfield(opts, 'sigmaValue')
            opts.sigmaValue = 7;
        end
        
end

if ~isfield(opts, 'normalizeL')
    opts.normalizeL = true;
end

if ~isfield(opts, 'classify_outliers')
    opts.classify_outliers = true; % default = 1% outliers removed
end

n = size(X,1);
outliers = false(1,n); % all data points are normal points initially

%% calculating affinities

[n,d] = size(X); % number of data points

norms2 = sum(X.*X,2);

switch opts.affinity
    
    case 'cosine'
        
        %X_norm = X./repmat(sqrt(norms2),1,size(X,2));
        if ~opts.isRowNormalized
            X_norm = bsxfun(@rdivide,X,sqrt(norms2));
        else
            X_norm = X;
        end
        W = X_norm*X_norm';
        
        if opts.sigmaValue > 1
            W = W.^opts.sigmaValue;
        elseif opts.sigmaValue<0
            W = W./(2-W);
        end
    
    case 'Gaussian'
        
        dists2 = -(2*X)*X';
        dists2 = bsxfun(@plus, dists2, norms2);
        dists2 = bsxfun(@plus, dists2, norms2');
        %dists2 = repmat(norms2,1,n) + repmat(norms2',n,1) - (2*X)*X';
        dists2_sort = sort(dists2, 2, 'ascend');
        
        switch opts.sigmaMethod
            case 'sigma'
                sigma2 = 2*opts.sigmaValue^2;
            case 'meanDist'
                sigma2 = 2*mean(sqrt(dists2_sort(:, opts.sigmaValue)))^2;
            case 'medianDist'
                sigma2 = 2*median(sqrt(dists2_sort(:, opts.sigmaValue)))^2;
            case 'selfTuning'
                sigma2 = 2*sqrt(dists2_sort(:,opts.sigmaValue))*sqrt(dists2_sort(:,opts.sigmaValue))';
        end
        
        W = exp(-dists2 ./ sigma2);

end

W(W<1e-16) = 0;
W(1:n+1:end) = 0;
        
%% remove outliers by using degrees
degrees = sum(W,2);

deg0_outliers = (degrees<1e-16);
n_out = sum(deg0_outliers); 

outliers(deg0_outliers) = 0; % 0 encodes outliers

if n_out < ceil(n*opts.alpha)
    
    n_out = ceil(n*opts.alpha);
    
    [~, inds_sort_degrees] = sort(degrees,'ascend');
    outliers(inds_sort_degrees(1:n_out)) = true;
    
end

inliers = ~outliers;
W = W(inliers, inliers);
degrees = degrees(inliers);

%% normalization

dvec_inv = 1./sqrt(degrees);

W_tilde = bsxfun(@times, W, dvec_inv);
W_tilde = bsxfun(@times, W_tilde, dvec_inv');
W_tilde = (W_tilde+W_tilde')/2;

%% calculate eigenvectors
[V,S] = eigs(W_tilde, k, 'LM', struct('issym', true, 'isreal', true));

if opts.t >= 0 % NCut or DM
    V = bsxfun(@times, V(:,2:k), dvec_inv);
end

if opts.t > 0 % DM with t time steps    
    lambdas = diag(S(2:k,2:k))' - mean(dvec_inv);
    V = bsxfun(@times, V, lambdas.^opts.t);
end

% L_2 row normalization
V = bsxfun(@rdivide, V, sqrt(sum(V.^2,2)));

%% kmeans clustering

labels = zeros(n,1);

if exist('kmeans','file')
    labels(inliers) = kmeans(V, k, 'replicates', 10);
elseif exist('litekmeans','file')
    labels(inliers) = litekmeans(V, k, 'replicates', 10); 
else 
    error('kmeans and litekmeans not found!')
end

%%
if opts.classify_outliers && any(outliers)
    
    switch opts.affinity
        case 'cosine'
            centers = zeros(k,d);
            for i = 1:k
                centers(i,:) = mean(X_norm(labels==i,:),1);
            end
            
            [~, labels(outliers)] = max(X_norm(outliers,:)*centers',[],2);
            
        otherwise
            warning('Note: outliers classification has not been implemented for this affinity!')
    end
       
end
