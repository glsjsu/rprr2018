clear

% Download the 5 files, train.data, test.data, train.label, test.label, and
% vocabulary.txt from the Matlab bydate version of the 20newsgroup data set
% at http://qwone.com/~jason/20Newsgroups/, and store them under the
% Data subdirectory.

fprintf('\n***processing raw counts***\n')

%% read 20news raw data
fprintf('\nreading raw counts...')

% read training data from file
fid = fopen('Data\train.data');
scanned_data = fscanf(fid, '%d %d %d',[3,1467345]); 
fclose(fid);
scanned_data1 = scanned_data'; % convert to (document id, term id, frequency) form

% read test data from file
fid = fopen('Data\test.data');
scanned_data = fscanf(fid, '%d %d %d',[3,967874]); 
fclose(fid);
scanned_data2 = scanned_data'; % convert to (document id, term id, frequency) form
scanned_data2(:,1) = scanned_data2(:,1)+11269; 

% combine
scanned_data = [scanned_data1; scanned_data2];
A = spconvert(scanned_data); % sparse matrix

% read training labels
fid = fopen('Data\train.label');
labels1 = fscanf(fid, '%d');
fclose(fid);

% read test labels
fid = fopen('Data\test.label');
labels2 = fscanf(fid, '%d');
fclose(fid);

% combine labels
labels = [labels1; labels2];

% read vocabulary
fid = fopen('Data\vocabulary.txt');
terms = textscan(fid, '%s\n');
terms = terms{1};

% cluster names
cls_names = {'alt.atheism', 'comp.graphics', 'comp.os.ms-windows.misc', 'comp.sys.ibm.pc.hardware',...
    'comp.sys.mac.hardware', 'comp.windows.x', 'misc.forsale', 'rec.autos', 'rec.motorcycles',...
    'rec.sport.baseball', 'rec.sport.hockey', 'sci.crypt', 'sci.electronics', 'sci.med', 'sci.space',...
    'soc.religion.christian', 'talk.politics.guns', 'talk.politics.mideast', 'talk.politics.misc',...
    'talk.religion.misc'};

%save Data\matlab-20news-bydate.mat A labels terms cls_names
 
%% documents processing 

termFreqCutoff   = 1; % binary conversion. This cutoff can be set higher than 1
maxDocFreq       = 939; % cut off for column triming
rowNormalization = 'L2'; % row normalization, can be 'None', 'L1', or 'L2'
colWeighting     = 'idf2'; % column weighting, can be 'None','IDF','IDF2'
 
% tfidf processing
fprintf('\ntf-idf weighting...')
t0 = cputime;
[A_tfidf, preservedDocs, preservedWords] = tfidfproc(A, termFreqCutoff, maxDocFreq, rowNormalization, colWeighting);
t = cputime-t0;
fprintf('...%3.1s secs\n', t)
 
y = labels(preservedDocs);
n = numel(y);
k = 20;

fprintf('n = %i, d = %i, s = %3.1f\n', n, size(A_tfidf,2), nnz(A_tfidf(:))/n)

%SVD 100
fprintf('\nperforming svd...')
t0 = cputime;
[U,S] = svds(A_tfidf,100);
A_tfidf_svd100 = bsxfun(@times, U, diag(S)');
t = cputime-t0;
fprintf('...%3.1s secs\n', t)

terms_tfidf = terms(preservedWords);

save Data\20news A_tfidf A_tfidf_svd100 y terms_tfidf cls_names