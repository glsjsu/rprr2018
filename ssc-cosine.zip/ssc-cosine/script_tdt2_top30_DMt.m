clear
close all
clc

% load Data\20news
% k = 20;

load Data\TDT2.mat
k = 30;
A = fea(gnd<=k,:);
B = A(:,sum(A,1)>0);
y = gnd(gnd<=k);

% load mnist
% %load pendigits
% %load usps
% B = [Xtr; Xtst];
% y = [ytr; ytst];
% y(y==0)=max(y)+1;
% k = 10;
% 
% clear Xtr Xtst ytr ytst

t_max = 15;

%% diffusion maps with varying step sizes
fprintf('***diffusion maps with different t on TDT2 data***\n')

accuracy_DM = zeros(1,t_max+2);
for t = -1:t_max
    
    fprintf('...t=%2.0f', t)
    
    inds_sc = ssc_cosine(B, k, struct('t', t, 'alpha', 0.01));
    inds_sc = bestMap(y,inds_sc);
        
    accuracy_DM(t+2) = sum(y==inds_sc)/length(y);
        
    fprintf('...accuracy = %1.3f \n', accuracy_DM(t+2))

end

%%

figure; 
plot(-1:t_max, 100*accuracy_DM, '--m*', 'markersize',14, 'linewidth',2)
%hold on
%plot([steps(1) steps(end)], [max_accuracy_NJW max_accuracy_NJW], 'k--', 'linewidth',2)
xlabel('t (#time steps)', 'fontsize', 14)
ylabel('clustering accuracy (%)', 'fontsize', 14)
xlim([-1 t_max])
set(gca, 'fontsize',14)
%legend({'Diffusion Maps', 'NJW'}, 'fontsize',12)
grid on


