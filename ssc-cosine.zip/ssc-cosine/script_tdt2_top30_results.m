clear

load Data\TDT2.mat
A = fea; 
labels = gnd;
clear fea gnd

% tf-idf weighting
%A(A>0)=1;
%A = bsxfun(@times, A, log(size(A,1)./sum(A>0,1)));

k_max = 30;
accuracy = ones(6,k_max);
runtime = zeros(6,k_max);

alpha = 0.01;

%% 
fprintf('\n***spectral clustering on TDT2 data (Fig. 4)***\n')

for k = 2:k_max
    
    fprintf('k=%i...\n',k)
    
    y = labels(labels<k+1);
    B = A(labels<k+1,:);
    B = B(:,sum(B,1)>0); % remove words with zero frequency
    
    cnt = 0;
    
    % plain NJW
    %fprintf('\nrunning plain NJW...')
    cnt = cnt+1;
    t0 = cputime;
    inds_sc = specluster(B, k, struct('t', -1, 'affinity', 'cosine', 'alpha', alpha));
    runtime(cnt,k) = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy(cnt, k) = sum(y == inds_sc)/length(y);
    %fprintf('accuracy=%0.4f...',accuracy(cnt, k))
    
    % plain NCut
    %fprintf('\nrunning plain NCut...')
    cnt = cnt+1;
    t0 = cputime;
    inds_sc = specluster(B, k, struct('t', 0, 'affinity', 'cosine', 'alpha', alpha));
    runtime(cnt,k) = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy(cnt, k) = sum(y == inds_sc)/length(y);
    %fprintf('accuracy=%0.4f...',accuracy(cnt, k))
    
    %plain DM1
    %fprintf('\nrunning plain DM1...')
    cnt = cnt+1;
    t0 = cputime;
    inds_sc = specluster(B, k, struct('t', 1, 'affinity', 'cosine', 'alpha', alpha));
    runtime(cnt,k) = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy(cnt, k) = sum(y == inds_sc)/length(y);
    %fprintf('accuracy=%0.4f...',accuracy(cnt, k))
    
    %scalable NJW
    %fprintf('\nrunning scalable NJW...')
    cnt = cnt+1;
    t0 = cputime;
    inds_sc = ssc_cosine(B, k, struct('t', -1, 'alpha', alpha));
    runtime(cnt,k) = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy(cnt, k) = sum(y == inds_sc)/length(y);
    %fprintf('accuracy=%0.4f...',accuracy(cnt, k))
    
    % scalable Ncut
    %fprintf('\nrunning scalable NCut...')
    cnt = cnt+1;
    t0 = cputime;
    inds_sc = ssc_cosine(B, k, struct('t', 0, 'alpha', alpha));
    runtime(cnt,k) = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy(cnt, k) = sum(y == inds_sc)/length(y);
    %fprintf('accuracy=%0.4f...',accuracy(cnt, k))
    
    % scalable DM1
    %fprintf('\nrunning scalable DM1...')
    cnt = cnt+1;
    t0 = cputime;
    inds_sc = ssc_cosine(B, k, struct('t', 1, 'alpha', alpha));
    runtime(cnt,k) = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy(cnt, k) = sum(y == inds_sc)/length(y);
    %fprintf('accuracy=%0.4f...\n',accuracy(cnt, k))
     
end

%% accuracy
k_max = 30;
figure; 
axes('Position',[0.1,0.15,0.85,0.8])
hold on
%plot(accuracy_sDM3, '--ks', 'markersize', 14, 'linewidth',2)
plot(accuracy(6,:), '--bo', 'markersize', 14, 'linewidth',2) %sDM1
plot(accuracy(5,:), '--cv', 'markersize', 14, 'linewidth',2) %sNcut
plot(accuracy(4,:), '--ks', 'markersize', 14, 'linewidth',2) %sNJW
plot(accuracy(3,:), '--m+', 'markersize', 14, 'linewidth',2) %DM1
plot(accuracy(2,:), '--gp', 'markersize', 14, 'linewidth',2) %Ncut
plot(accuracy(1,:), '--r*', 'markersize', 14, 'linewidth',2) %NJW
xlabel('k (#clusters)', 'fontsize',14)
ylabel('Clustering accuracy', 'fontsize',14)
grid on
xlim([1 k_max])
set(gca, 'xTick', 1:k_max,'fontsize',14)
legend({'scalable DM1', 'scalable NCut','scalable NJW', 'plain DM1', 'plain NCut','plain NJW'}, 'fontsize', 14)
grid on

%% run time
figure;
axes('Position',[0.1,0.15,0.85,0.8])
hold on
plot(runtime(1,:), '--r*', 'markersize', 14, 'linewidth',2)
plot(runtime(2,:), '--gp', 'markersize', 14, 'linewidth',2)
plot(runtime(3,:), '--m+', 'markersize', 14, 'linewidth',2)
plot(runtime(4,:), '--ks', 'markersize', 14, 'linewidth',2)
plot(runtime(5,:), '--cv', 'markersize', 14, 'linewidth',2)
plot(runtime(6,:), '--bo', 'markersize', 14, 'linewidth',2)
xlabel('k (#clusters)', 'fontsize',14)
ylabel('CPU time (in seconds)', 'fontsize',14)
grid on
xlim([2 k_max])
set(gca, 'xTick', 1:k_max,'fontsize',14)
legend({'plain NJW', 'plain NCut', 'plain DM1', 'scalable NJW', 'scalable NCut','scalable DM1'}, 'fontsize', 14)
grid on
