clear

load Data\20news
n = numel(y);
k = max(y);

m = 6; % number of methods
accuracy = zeros(2,m);
runtime = zeros(2,m);

alpha = 0.01;

%% plain and scalable spectral clustering on two versions of 20news data
fprintf('\n***spectral clustering on 20news data (Table I)***\n')

for i = 1:2
    
    if i==1
        X = A_tfidf; % no projection
        fprintf('\nno projection: \n')
    else
        X = A_tfidf_svd100; % projected data into 100 dimensions
        fprintf('\n100d projection: \n')
    end
    
    cnt = 0;
    % vanilla NJW
    fprintf('\nrunning plain NJW...')
    cnt = cnt+1;
    t0=cputime;
    inds_sc = specluster(X, k, struct('t', -1, 'affinity', 'cosine', 'alpha', alpha));
    runtime(i,cnt) = cputime -t0;
    accuracy(i,cnt) = sum(y == bestMap(y,inds_sc))/n;
    fprintf('accuracy=%0.4f\n', accuracy(i,cnt))
    
    % vanilla Ncut
    fprintf('running plain NCut...')
    cnt = cnt+1;
    t0=cputime;
    inds_sc = specluster(X, k, struct('t', 0, 'affinity', 'cosine', 'alpha', alpha));
    runtime(i,cnt) = cputime - t0;
    accuracy(i,cnt) = sum(y == bestMap(y,inds_sc))/n;
    fprintf('accuracy=%0.4f\n', accuracy(i,cnt))
    
    % vanilla DM1
    fprintf('running plain DM1...')
    cnt = cnt+1;
    t0=cputime;
    inds_sc = specluster(X, k, struct('t', 1, 'affinity', 'cosine', 'alpha', alpha));
    runtime(i,cnt) = cputime - t0;
    accuracy(i,cnt) = sum(y == bestMap(y,inds_sc))/n;
    fprintf('accuracy=%0.4f\n', accuracy(i,cnt))
    
    % NJW
    fprintf('\nrunning scalable NJW...')
    cnt = cnt + 1;
    t0=cputime;
    inds_sc = ssc_cosine(X, k, struct('t', -1, 'alpha', alpha));
    runtime(i,cnt) = cputime - t0;
    accuracy(i,cnt) = sum(y == bestMap(y,inds_sc))/n;
    fprintf('accuracy=%0.4f\n', accuracy(i,cnt))
    
    % Ncut
    fprintf('running scalable NCut...')
    cnt = cnt+1;
    t0=cputime;
    inds_sc = ssc_cosine(X, k, struct('t', 0, 'alpha', alpha));
    runtime(i,cnt) = cputime - t0;
    accuracy(i,cnt) = sum(y == bestMap(y,inds_sc))/n;
    fprintf('accuracy=%0.4f\n', accuracy(i,cnt))
    
    % DM with t=1
    fprintf('running scalable DM1...')
    cnt = cnt+1;
    t0=cputime;
    inds_sc = ssc_cosine(X, k, struct('t', 1, 'alpha', alpha));
    runtime(i,cnt) = cputime -t0;
    accuracy(i,cnt) = sum(y == bestMap(y,inds_sc))/n;
    fprintf('accuracy=%0.4f\n', accuracy(i,cnt))
    
end
