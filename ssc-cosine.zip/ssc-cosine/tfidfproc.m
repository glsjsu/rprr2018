function [A, preservedRows, preservedCols] = tfidfproc( ...
    A,                ... document term frequency matrix
    termFreqCutoff,   ... cut off used to truncate high frequency counts
    maxDocFreq,       ... cut off used to remove highly frequent words
    rowNormalization, ... whether to perform row normalization: 'none', 'L1', 'L2',
    colWeighting)     ... whether to apply column weighting such as 'none', 'IDF', 'IDF2',

%% frequency truncation
A(A>termFreqCutoff) = termFreqCutoff; % binary if termFreqCutoff = 1

%% column pruning
colsums = sum(A>0,1);
preservedCols = (colsums<maxDocFreq & colsums>1);
A = A(:, preservedCols);
colsums = colsums(preservedCols);

rowsums = sum(A,2);
preservedRows = (rowsums>0);
A = A(preservedRows,:);

%% column weighting
ndocs = size(A,1);

switch lower(colWeighting)
    case 'idf'
        colWeights = log(ndocs./colsums);
    case 'idf2'
        colWeights = log(ndocs./colsums).^2;
    case 'sqrtl1'
        colWeights = 1./sqrt(colsums);
end

if ~strcmpi(colWeighting, 'none')
    A = bsxfun(@times, A, colWeights);
end

%% row normalization
switch lower(rowNormalization)      
    case 'l1'
        row_norms = sum(A,2);
    case 'l2'
        row_norms = sqrt(sum(A.^2,2));
end

if ~strcmpi(rowNormalization, 'none')
    A = bsxfun(@rdivide, A, row_norms);
end

