clear

fprintf('\n***getting insights from clusters (Fig. 2)***\n')

load Data\20news

%% spectral clustering

n = numel(y);
k = 20;

t0 = cputime;
[inds_sc, outliers] = ssc_cosine(A_tfidf_svd100, k, struct('t', 1, 'alpha', 0.01));
runtime = cputime - t0;
inds_sc = bestMap(y,inds_sc);
accuracy = sum(y == inds_sc)/n;

fprintf('accuracy = %0.3f, cputime = %3.1f\n', accuracy, runtime) 

%% get insights from the clusters

inds_sc(outliers) = 0;

groups = [2 7 8 12 16 18];
for i = 1:numel(groups)
    
    cls = (inds_sc==groups(i));
    
    [U,S,V] = svds(A_tfidf(cls,:),3);
    
    %figure; gcplot(U.*repmat(diag(S)',sum(cls),1))
    %legend(cls_names{index},'fontsize',14)
    
    v = V(:,1);
    [max_v, idx_max] = max(abs(v)); 
    if v(idx_max)<0
        v = -v;
    end
    [v_sort, inds_sort] = sort(v, 'descend');
    
    m=20;
    figure; ax.XTickLabelRotation=45;
    plot(v_sort(1:m), '.', 'markersize',14)
    set(gca, 'xTick', 1:m, 'XTickLabel', terms_tfidf(inds_sort(1:m)), ax, 'fontsize',14)
    title(cls_names{mode(y(cls))}, 'fontsize',16)
    grid on
    
end