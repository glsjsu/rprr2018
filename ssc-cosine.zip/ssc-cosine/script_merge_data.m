% 20news and mnist are too large in size to be uploaded to Github, 
% so each of them has been split into two parts to reduce the size. 

load Data\20news_part1
load Data\20news_part2
save Data\20news A_tfidf A_tfidf_svd100 terms_tfidf y cls_names

load Data\mnist_part1
load Data\mnist_part2
Xtr = [Xtr1; Xtr2];
save Data\mnist Xtr Xtst ytr ytst