clear

load Data\20news

n = numel(y);
k = 20;

alphas = 0:0.005:0.1; % percentage of outliers to be removed
n_alphas = length(alphas);

accuracy = zeros(6,n_alphas); 

%% spectral clustering with cosine similarity
fprintf('*** sensitivity study of parameter alpha (all 3 scalable methods)*** \n')

for i = 1:n_alphas
    fprintf('...alpha=%1.3f...\n', alphas(i))

    % svd 100
    for t = -1:1                
        inds_sc = ssc_cosine(A_tfidf_svd100, k, struct('t', t, 'alpha', alphas(i)));
        inds_sc = bestMap(y,inds_sc);
        accuracy(t+2,i) = sum(y==inds_sc)/n;
    end
    
    % no projection
    for t = -1:1                
        inds_sc = ssc_cosine(A_tfidf, k, struct('t', t, 'alpha', alphas(i)));
        inds_sc = bestMap(y,inds_sc);
        accuracy(t+5,i) = sum(y==inds_sc)/n;
    end
        
end

%%
accuracy = 100*accuracy;

figure; 
hold on
plot(alphas, accuracy(1,:), '--ro', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(2,:), '--bo', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(3,:), '--mo', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(4,:), '--r*', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(5,:), '--b*', 'markersize',14, 'linewidth',2)
plot(alphas, accuracy(6,:), '--m*', 'markersize',14, 'linewidth',2)
xlabel('\alpha (fraction of outliers)','fontsize',14)
ylabel('clustering accuracy (%)','fontsize',14)
grid on
legend({'sNJW (SVD 100)', 'sNCut (SVD 100)', 'sDM1 (SVD 100)', ...
        'sNJW (no projection)', 'sNCut (no projection)', 'sDM1 (no projection)'}, ... 
        'fontsize', 14)
set(gca, 'fontsize',14)

