clear

datasets = {'pendigits', 'usps', 'mnist'};

alpha = 0.01;

%% experiments

fprintf('\n***NJW spectral clustering on digits data (Table II)***\n')

for i = 1:3
    
    fprintf('\nloading %s...\n', datasets{i})
    eval(['load Data\' datasets{i}])
    
    A = [Xtr; Xtst];
    y = [ytr; ytst];
    y(y==0)=max(y)+1;
    clear Xtr Xtst ytr ytst
    
    n = numel(y);
    k = max(y);
    
    fprintf('running scalable NJW...')
    t0 = cputime;
    inds_sc = ssc_cosine(A, k, struct('t', -1, 'affinity', 'cosine', 'alpha', alpha));
    runtime = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy = sum(y == inds_sc)/length(y);
    fprintf('accuracy=%0.4f, cputime=%2.1f\n', accuracy, runtime)
    
    fprintf('running plain NJW...')
    t0 = cputime;
    inds_sc = specluster(A, k, struct('t', -1, 'affinity', 'cosine', 'alpha', alpha));
    runtime = cputime - t0;
    inds_sc = bestMap(y,inds_sc);
    accuracy = sum(y == inds_sc)/length(y);
    fprintf('accuracy=%2.2f, cputime=%2.1f\n', accuracy, runtime)
    
end
    